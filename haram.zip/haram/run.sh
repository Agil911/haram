php multiakun.php
sh multiakun.sh